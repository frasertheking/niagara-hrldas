#!/bin/sh
echo "SUCCESS sh test"
