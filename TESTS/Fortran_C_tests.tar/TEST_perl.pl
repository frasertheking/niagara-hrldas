#!/usr/bin/perl
 print "SUCCESS perl test\n";
