#include <stdio.h>

int main(int argc, char ** argv)
 {
     printf ("SUCCESS test 3 C only\n") ;
     return (0) ;
 }
